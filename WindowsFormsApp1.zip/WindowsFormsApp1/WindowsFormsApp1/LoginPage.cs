﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            RegisterPage rp = new RegisterPage();
            rp.Show();
        }

        private void login_Click(object sender, EventArgs e)
        {

            Brower b = new Brower();
            string username = textBox1.Text;
            string password = textBox2.Text;
            if(RegisterPage.un == username && RegisterPage.password == password)
            {
                this.Hide();
                b.Show();
            } else
            {
                if(username == "admin" && password == "12345678")
                {
                    this.Hide();
                    b.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User name of Password","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
            }
        }
    }
}
