﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RegisterPage : Form
    {
        public static string un;
        public static string mail;
        public static string phone;
        public static string password;
        public static string confirm;
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void Username_TextChanged(object sender, EventArgs e)
        {

        }

        private void Mail_TextChanged(object sender, EventArgs e)
        {

        }

        private void Phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void ConfirmPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void Register_Click(object sender, EventArgs e)
        {
            un = Username.Text;
            mail = Mail.Text;
            phone = Phone.Text;
            password = Password.Text;
            confirm = ConfirmPassword.Text;

            bool isValid = true;

            if(string.IsNullOrEmpty(un) || string.IsNullOrEmpty(mail) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirm))
            {
                isValid = false;
                MessageBox.Show("The Input Fields Cannot Be empty","Warning",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!Regex.IsMatch(un, @"^[a-zA-Z0-9_-]{3,6}$"))
            {
                isValid = false;
                MessageBox.Show("Invalid username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!Regex.IsMatch(mail, @"^[a-zA-Z0-9._+%]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
            {
                isValid = false;
                MessageBox.Show("Invalid Mail ID", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!Regex.IsMatch(phone, @"^\d{10}$"))
            {
                isValid = false;
                MessageBox.Show("Invalid Phone No", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!Regex.IsMatch(password, @"^[a-zA-Z0-9!@#$%^&*()_+.,?::]{8,}$"))
            {
                isValid = false;
                MessageBox.Show("Invalid Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if(password != confirm)
            {
                isValid = false;
                MessageBox.Show("Password does not match", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (!isValid)
            {
                return;
            }

            this.Hide();
            LoginPage lp = new LoginPage();
            lp.Show();
        }
    }
}
